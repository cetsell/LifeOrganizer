export interface CalendarEvent {
  id: string;
  title: string;
  startTime: string; // format: "HH:mm"
  endTime: string; // format: "HH:mm"
  date: string; // format: "YYYY-MM-DD"
  color: string;
  notes?: string;
}

export interface Task {
  id: string;
  title: string;
  category: 'todo' | 'upcoming' | 'later';
  priority?: 'low' | 'medium' | 'high';
  dueDate?: string;
  completed: boolean;
}

export interface TimeBlock {
  hour: number;
  date: string;
  notes?: string;
  events: CalendarEvent[];
}

export interface WeekData {
  startDate: Date;
  endDate: Date;
  days: Date[];
}