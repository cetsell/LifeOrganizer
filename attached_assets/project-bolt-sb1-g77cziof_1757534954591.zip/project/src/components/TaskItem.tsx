import React from 'react';
import { Check, Clock, Calendar, GripVertical } from 'lucide-react';
import { Task } from '../types';

interface TaskItemProps {
  task: Task;
  onToggleComplete: (id: string) => void;
  onMove: (id: string, category: Task['category']) => void;
  onEdit: (task: Task) => void;
  draggable?: boolean;
  onDragStart?: (e: React.DragEvent, task: Task) => void;
}

const TaskItem: React.FC<TaskItemProps> = ({ 
  task, 
  onToggleComplete, 
  onMove, 
  onEdit,
  draggable = true,
  onDragStart 
}) => {
  const priorityColors = {
    low: 'bg-blue-50 border-blue-200',
    medium: 'bg-yellow-50 border-yellow-200',
    high: 'bg-red-50 border-red-200'
  };

  const handleDragStart = (e: React.DragEvent) => {
    if (onDragStart) {
      onDragStart(e, task);
    }
  };

  return (
    <div
      className={`group flex items-center gap-3 p-3 border rounded-lg cursor-pointer hover:shadow-sm transition-all duration-200 ${
        task.completed ? 'bg-gray-50 border-gray-200' : 'bg-white border-gray-200 hover:border-gray-300'
      } ${task.priority ? priorityColors[task.priority] : ''}`}
      draggable={draggable && !task.completed}
      onDragStart={handleDragStart}
      onClick={(e) => {
        e.stopPropagation();
        onEdit(task);
      }}
    >
      {draggable && !task.completed && (
        <GripVertical className="w-4 h-4 text-gray-400 opacity-0 group-hover:opacity-100 transition-opacity" />
      )}
      
      <button
        onClick={() => onToggleComplete(task.id)}
        onClick={(e) => {
          e.stopPropagation();
          onToggleComplete(task.id);
        }}
        className={`w-5 h-5 rounded border-2 flex items-center justify-center transition-colors ${
          task.completed 
            ? 'bg-green-500 border-green-500 text-white' 
            : 'border-gray-300 hover:border-gray-400'
        }`}
      >
        {task.completed && <Check className="w-3 h-3" />}
      </button>

      <div className="flex-1 min-w-0">
        <p className={`text-sm truncate ${task.completed ? 'line-through text-gray-500' : 'text-gray-900'}`}>
          {task.title}
        </p>
        {task.dueDate && (
          <div className="flex items-center gap-1 mt-1">
            <Clock className="w-3 h-3 text-gray-400" />
            <span className="text-xs text-gray-500">{task.dueDate}</span>
          </div>
        )}
      </div>

      {task.category === 'upcoming' && (
        <Calendar className="w-4 h-4 text-blue-500" />
      )}
    </div>
  );
};

export default TaskItem;