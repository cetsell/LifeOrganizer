import React from 'react';
import { CalendarEvent, TimeBlock as TimeBlockType, WeekData } from '../types';
import { getDayName, getMonthDay, formatDate } from '../utils/dateUtils';
import TimeBlock from './TimeBlock';

interface WeekViewProps {
  weekData: WeekData;
  timeBlocks: Record<string, TimeBlockType>;
  expandedBlock: string | null;
  onTimeBlockClick: (hour: number, date: string) => void;
  onNotesChange: (hour: number, date: string, notes: string) => void;
  onAddEvent: (hour: number, date: string) => void;
  onEditEvent: (event: CalendarEvent) => void;
  onTaskDrop: (hour: number, date: string, taskId: string) => void;
  isCondensed?: boolean;
  title?: string;
  onWeekClick?: () => void;
  showWeekends?: boolean;
  screenSize?: 'mobile' | 'tablet' | 'desktop' | 'large' | 'ultrawide';
  dayDisplay?: Array<{
    day: Date;
    isExpanded: boolean;
    timeBlocks: Record<string, TimeBlockType>;
  }>;
}

const WeekView: React.FC<WeekViewProps> = ({
  weekData,
  timeBlocks,
  expandedBlock,
  onTimeBlockClick,
  onNotesChange,
  onAddEvent,
  onEditEvent,
  onTaskDrop,
  isCondensed = false,
  title,
  onWeekClick,
  showWeekends = true,
  screenSize = 'desktop',
  dayDisplay
}) => {
  const hours = Array.from({ length: 18 }, (_, i) => i + 6); // 6 AM to 11 PM

  const handleDrop = (hour: number, date: string) => (e: React.DragEvent) => {
    e.preventDefault();
    const taskId = e.dataTransfer.getData('text/plain');
    if (taskId) {
      onTaskDrop(hour, date, taskId);
    }
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
  };

  if (isCondensed) {
    // Responsive sizing based on screen size
    const getResponsiveSizing = () => {
      const isPrevious = title?.includes('Previous');
      
      switch (screenSize) {
        case 'mobile':
          return {
            maxItems: isPrevious ? 3 : 2,
            containerHeight: isPrevious ? 'h-16' : 'h-12',
            textLength: 8,
            fontSize: 'text-[9px]'
          };
        case 'tablet':
          return {
            maxItems: isPrevious ? 4 : 3,
            containerHeight: isPrevious ? 'h-20' : 'h-16',
            textLength: 10,
            fontSize: 'text-[10px]'
          };
        case 'desktop':
          return {
            maxItems: isPrevious ? 6 : 4,
            containerHeight: isPrevious ? 'h-28' : 'h-24',
            textLength: 12,
            fontSize: 'text-[10px]'
          };
        case 'large':
          return {
            maxItems: isPrevious ? 8 : 6,
            containerHeight: isPrevious ? 'h-32' : 'h-28',
            textLength: 15,
            fontSize: 'text-xs'
          };
        case 'ultrawide':
          return {
            maxItems: isPrevious ? 10 : 8,
            containerHeight: isPrevious ? 'h-36' : 'h-32',
            textLength: 18,
            fontSize: 'text-xs'
          };
        default:
          return {
            maxItems: isPrevious ? 6 : 4,
            containerHeight: isPrevious ? 'h-28' : 'h-24',
            textLength: 12,
            fontSize: 'text-[10px]'
          };
      }
    };
    
    const { maxItems, containerHeight, textLength, fontSize } = getResponsiveSizing();
    
    return (
      <div
        className={`bg-white border border-gray-200 rounded-lg p-2 cursor-pointer hover:shadow-md transition-all duration-200`}
        onClick={onWeekClick}
      >
        {title && (
          <h3 className={`${screenSize === 'mobile' ? 'text-[10px]' : 'text-xs'} font-medium text-gray-600 mb-2`}>{title}</h3>
        )}
        <div className={`grid ${screenSize === 'mobile' ? 'gap-0.5' : 'gap-1'} ${showWeekends ? 'grid-cols-7' : 'grid-cols-5'}`}>
          {(showWeekends ? weekData.days : weekData.days.filter(day => {
            const dayOfWeek = day.getDay();
            return dayOfWeek !== 0 && dayOfWeek !== 6;
          })).map((day) => (
            <div key={day.toISOString()} className="text-center">
              <div className={`${screenSize === 'mobile' ? 'text-[9px]' : 'text-xs'} font-medium text-gray-900 mb-1`}>
                {getDayName(day, true).toUpperCase()} {getMonthDay(day)}
              </div>
              <div className={`space-y-1 ${containerHeight} flex flex-col justify-start`}>
                {(() => {
                  const dateStr = formatDate(day);
                  const dayItems: Array<{ type: 'event' | 'note'; color: string; text: string; id: string }> = [];
                  
                  // Collect all events for this day (deduplicated)
                  const seenEvents = new Set();
                  hours.forEach(hour => {
                    const blockKey = `${dateStr}-${hour}`;
                    const block = timeBlocks[blockKey];
                    if (block?.events) {
                      block.events.forEach(event => {
                        if (!seenEvents.has(event.id)) {
                          seenEvents.add(event.id);
                          dayItems.push({ 
                            type: 'event', 
                            color: event.color, 
                            text: event.title,
                            id: event.id 
                          });
                        }
                      });
                    }
                  });
                  
                  // Collect all note blocks for this day
                  hours.forEach(hour => {
                    const blockKey = `${dateStr}-${hour}`;
                    const block = timeBlocks[blockKey];
                    if (block?.notes && block.notes.trim().length > 0) {
                      dayItems.push({ 
                        type: 'note', 
                        color: '#9CA3AF', 
                        text: block.notes.trim(),
                        id: `note-${hour}` 
                      });
                    }
                  });
                  
                  // Show up to maxItems
                  const itemsToShow = dayItems.slice(0, maxItems);
                  
                  return (
                    <>
                      {itemsToShow.map((item, index) => (
                        <div
                          key={`${item.type}-${index}`}
                          className={`${screenSize === 'mobile' ? 'h-3 px-1' : 'h-4 px-2'} rounded text-white font-medium flex items-center justify-start overflow-hidden`}
                          style={{ backgroundColor: item.color }}
                          title={item.text}
                        >
                          <span className={`truncate ${fontSize} leading-tight`}>
                            {item.text.length > textLength ? item.text.substring(0, textLength) + '...' : item.text}
                          </span>
                        </div>
                      ))}
                    </>
                  );
                })()}
              </div>
            </div>
          ))}
        </div>
      </div>
    );
  }

  // Use dayDisplay if provided, otherwise use weekData.days
  const baseDays = dayDisplay || weekData.days.map(day => ({
    day,
    isExpanded: false,
    timeBlocks: timeBlocks
  }));
  
  // Filter days based on showWeekends
  const daysToRender = showWeekends 
    ? baseDays 
    : baseDays.filter(({ day }) => {
        const dayOfWeek = day.getDay();
        return dayOfWeek !== 0 && dayOfWeek !== 6; // Hide Sunday (0) and Saturday (6)
      });

  // Check if any day is expanded
  const expandedDay = expandedBlock ? expandedBlock.split('-').slice(0, -1).join('-') : null;

  return (
    <div className="flex gap-2 h-full">
      {daysToRender.map(({ day, isExpanded, timeBlocks: dayTimeBlocks }) => {
        const dateStr = formatDate(day);
        const isDayExpanded = expandedDay === dateStr;
        const hasAnyExpanded = expandedDay !== null;
        
        return (
          <div 
            key={day.toISOString()} 
            className={`bg-white border border-gray-200 rounded-lg overflow-hidden shadow-sm transition-all duration-300 ${
              isDayExpanded ? 'flex-1' : hasAnyExpanded ? 'w-32' : 'flex-1'
            }`}
          >
            {/* Day Header */}
            <div className={`${hasAnyExpanded ? 'h-12' : 'h-16'} border-b border-gray-200 flex flex-col items-center justify-center bg-gray-50`}>
              <div className="text-xs font-medium text-gray-600">
                {getDayName(day, true).toUpperCase()}
              </div>
              <div className={`${hasAnyExpanded ? 'text-sm' : 'text-lg'} font-bold text-gray-900`}>
                {getMonthDay(day)}
              </div>
            </div>
            
            {/* Time Blocks for This Day */}
            <div className="divide-y divide-gray-200 h-full overflow-y-auto scrollbar-thin">
              {hours.map(hour => {
                const blockKey = `${dateStr}-${hour}`;
                const block = dayTimeBlocks[blockKey];
                const isBlockExpanded = expandedBlock === blockKey;
                
                return (
                  <TimeBlock
                    key={blockKey}
                    hour={hour}
                    date={dateStr}
                    events={block?.events || []}
                    notes={block?.notes}
                    isExpanded={isBlockExpanded}
                    isDayExpanded={isDayExpanded}
                    onClick={() => onTimeBlockClick(hour, dateStr)}
                    onNotesChange={(notes) => onNotesChange(hour, dateStr, notes)}
                    onAddEvent={() => onAddEvent(hour, dateStr)}
                    onEditEvent={onEditEvent}
                    onDrop={handleDrop(hour, dateStr)}
                    onDragOver={handleDragOver}
                  />
                );
              })}
            </div>
          </div>
        );
      })}
    </div>
  );
};

export default WeekView;