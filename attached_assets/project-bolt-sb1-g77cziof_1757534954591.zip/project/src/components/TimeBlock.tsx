import React from 'react';
import { Clock, Plus } from 'lucide-react';
import { CalendarEvent } from '../types';
import { formatTime, formatDate, isSameDay } from '../utils/dateUtils';

interface TimeBlockProps {
  hour: number;
  date: string;
  events: CalendarEvent[];
  notes?: string;
  isExpanded: boolean;
  isDayExpanded: boolean;
  onClick: () => void;
  onNotesChange: (notes: string) => void;
  onAddEvent: () => void;
  onEditEvent: (event: CalendarEvent) => void;
  onDrop: (e: React.DragEvent) => void;
  onDragOver: (e: React.DragEvent) => void;
}

const getEventPosition = (event: CalendarEvent, currentHour: number) => {
  const startHour = parseInt(event.startTime.split(':')[0]);
  const endHour = parseInt(event.endTime.split(':')[1]);
  const startMinutes = parseInt(event.startTime.split(':')[1]);
  const endMinutes = parseInt(event.endTime.split(':')[1]);
  
  // Calculate if this is the first, middle, or last block for this event
  const isFirst = startHour === currentHour;
  const isLast = endHour === currentHour || (endHour === currentHour + 1 && endMinutes === 0);
  const isMiddle = !isFirst && !isLast && currentHour > startHour && currentHour < endHour;
  
  return { isFirst, isLast, isMiddle, startHour, endHour };
};

const TimeBlock: React.FC<TimeBlockProps> = ({
  hour,
  date,
  events,
  notes,
  isExpanded,
  isDayExpanded,
  onClick,
  onNotesChange,
  onAddEvent,
  onEditEvent,
  onDrop,
  onDragOver
}) => {
  const timeLabel = formatTime(hour);
  const hasEvents = events.length > 0;
  const hasNotes = notes && notes.trim().length > 0;
  
  // Check if this is the current time block
  const now = new Date();
  const isToday = isSameDay(new Date(date), now);
  const currentHour = now.getHours();
  const isCurrentHour = isToday && currentHour === hour;
  const isCurrentTime = isToday && currentHour === hour;
  
  // Calculate current time position within the hour
  const getCurrentTimePosition = () => {
    if (!isCurrentHour) return 0;
    const minutes = now.getMinutes();
    return (minutes / 60) * 100; // Convert to percentage
  };
  
  // Get preview text based on day expansion
  const getNotesPreview = (maxLength: number) => {
    if (!hasNotes) return '';
    const trimmed = notes!.trim();
    return trimmed.length > maxLength ? trimmed.substring(0, maxLength) + '...' : trimmed;
  };

  return (
    <div
      className={`border border-gray-200 transition-all duration-300 ${
        isCurrentHour
          ? 'bg-blue-50 border-blue-300 shadow-sm' 
          : isExpanded 
          ? 'bg-slate-50 border-slate-300 shadow-lg z-10 relative' 
          : hasEvents || hasNotes 
            ? 'bg-white hover:bg-gray-50 cursor-pointer' 
            : 'bg-gray-50 hover:bg-gray-100 cursor-pointer'
      } ${isExpanded && isCurrentHour ? 'border-t-4 border-t-red-500' : ''}`}
      style={{ 
        height: isExpanded ? '300px' : '64px',
        minHeight: isExpanded ? '300px' : '64px'
      }}
      onClick={!isExpanded ? onClick : undefined}
      onDrop={onDrop}
      onDragOver={onDragOver}
    >
      {isExpanded ? (
        <div className="p-4 h-full flex flex-col">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-2">
              <Clock className="w-4 h-4 text-slate-600" />
              <span className="font-medium text-slate-900">{timeLabel}</span>
              <span className="text-sm text-slate-500">{new Date(date).toLocaleDateString()}</span>
            </div>
            <button
              onClick={onAddEvent}
              className="flex items-center gap-1 px-2 py-1 text-sm bg-slate-100 hover:bg-slate-200 rounded transition-colors"
            >
              <Plus className="w-3 h-3" />
              Event
            </button>
          </div>

          {events.length > 0 && (
            <div className="mb-4 space-y-2">
              {events.map(event => {
                const position = getEventPosition(event, hour);
                return (
                <div
                  key={event.id}
                  onClick={(e) => {
                    e.stopPropagation();
                    onEditEvent(event);
                  }}
                    className={`p-2 border-l-4 ${
                      position.isFirst ? 'rounded-t' : position.isLast ? 'rounded-b' : ''
                    } ${position.isMiddle ? 'border-t-0 border-b-0' : ''} cursor-pointer hover:opacity-80 transition-opacity`}
                  style={{ backgroundColor: event.color + '20', borderLeftColor: event.color }}
                >
                    {position.isFirst && (
                      <>
                        <p className="font-medium text-sm">{event.title}</p>
                        <p className="text-xs text-gray-600">{event.startTime} - {event.endTime}</p>
                        {event.notes && (
                          <p className="text-xs text-gray-500 mt-1">{event.notes}</p>
                        )}
                      </>
                    )}
                    {position.isMiddle && (
                      <p className="font-medium text-sm text-gray-400">↳ {event.title}</p>
                    )}
                    {position.isLast && !position.isFirst && (
                      <p className="font-medium text-sm text-gray-400">↳ {event.title} (ends)</p>
                    )}
                </div>
                );
              })}
            </div>
          )}

          <div className="flex-1 flex flex-col">
            <label className="text-sm font-medium text-slate-700 mb-2">Notes</label>
            <textarea
              value={notes || ''}
              onChange={(e) => onNotesChange(e.target.value)}
              placeholder="Add your notes for this time block..."
              className="flex-1 p-3 border border-gray-300 rounded-lg resize-none focus:ring-2 focus:ring-slate-500 focus:border-transparent text-sm"
            />
          </div>
        </div>
      ) : (
        <div className="p-2 h-full flex flex-col">
          <div className="text-xs text-gray-500 mb-1">{timeLabel}</div>
          <div className="flex-1 min-h-0 space-y-1">
            {/* Events and Notes on same line */}
            {(events.length > 0 || hasNotes) && (
              <div className="flex items-start gap-1 min-h-0">
                {/* Events */}
                <div className="flex flex-wrap gap-1 flex-shrink-0">
                {events.map(event => {
                  const position = getEventPosition(event, hour);
                  return (
                  <div
                    key={event.id}
                    onClick={(e) => {
                      e.stopPropagation();
                      onEditEvent(event);
                    }}
                    className={`p-1 text-xs font-medium text-white rounded cursor-pointer hover:opacity-80 transition-opacity max-w-20 ${
                      position.isFirst ? 'rounded-t' : position.isLast ? 'rounded-b' : ''
                    } ${position.isMiddle ? 'opacity-75' : ''}`}
                    style={{ backgroundColor: event.color }}
                  >
                    {position.isFirst && <span className="truncate block">{event.title}</span>}
                    {position.isMiddle && <span className="text-center">↕</span>}
                    {position.isLast && !position.isFirst && <span className="text-center">↑</span>}
                  </div>
                  );
                })}
                </div>
                
                {/* Notes */}
                {hasNotes && (
                  <div className="text-[10px] text-gray-600 bg-gray-100 px-1 py-1 rounded flex-1 min-w-0">
                    <div className="truncate">
                      {getNotesPreview(isDayExpanded ? 20 : 15)}
                    </div>
                  </div>
                )}
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};

export default TimeBlock;