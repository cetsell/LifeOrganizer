import React, { useState } from 'react';
import { MoreHorizontal, Calendar } from 'lucide-react';
import { Task } from '../types';
import TaskItem from './TaskItem';
import GoogleCalendarButton from './GoogleCalendarButton';

interface TaskSidebarProps {
  tasks: Task[];
  onGoogleSync: () => void;
  onAddTask: (category: Task['category'], title: string) => void;
  onToggleTask: (id: string) => void;
  onMoveTask: (id: string, category: Task['category']) => void;
  onEditTask: (task: Task) => void;
  onDragStart: (e: React.DragEvent, task: Task) => void;
  onJumpToNow: () => void;
}

const TaskSidebar: React.FC<TaskSidebarProps> = ({
  tasks,
  onGoogleSync,
  onAddTask,
  onToggleTask,
  onMoveTask,
  onEditTask,
  onDragStart,
  onJumpToNow
}) => {
  const [inputValues, setInputValues] = useState<Record<Task['category'], string>>({
    todo: '',
    upcoming: '',
    later: ''
  });

  const categories = [
    { key: 'todo' as const, title: 'To-Do', color: 'bg-blue-500' },
    { key: 'upcoming' as const, title: 'Upcoming', color: 'bg-orange-500' },
    { key: 'later' as const, title: 'Later', color: 'bg-purple-500' }
  ];

  const getTasksByCategory = (category: Task['category']) => {
    return tasks.filter(task => task.category === category);
  };

  // Calculate dynamic flex values based on task counts
  const getFlexValue = (category: Task['category']) => {
    const taskCount = getTasksByCategory(category).length;
    const minFlex = 0.5; // Minimum space for empty categories
    const maxFlex = 3; // Maximum space for categories with many tasks
    
    if (taskCount === 0) return minFlex;
    if (taskCount <= 2) return 1;
    if (taskCount <= 5) return 1.5;
    if (taskCount <= 8) return 2;
    return maxFlex;
  };
  const handleInputChange = (category: Task['category'], value: string) => {
    setInputValues(prev => ({ ...prev, [category]: value }));
  };

  const handleKeyPress = (category: Task['category'], e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && inputValues[category].trim()) {
      onAddTask(category, inputValues[category].trim());
      setInputValues(prev => ({ ...prev, [category]: '' }));
    }
  };

  const formatTodaysDate = () => {
    const today = new Date();
    return today.toLocaleDateString('en-US', { 
      weekday: 'short',
      month: 'short', 
      day: 'numeric' 
    });
  };

  return (
    <div className="w-80 bg-white border-l border-gray-200 flex flex-col h-full">
      <div className="p-6 border-b border-gray-200">
        <div className="flex items-center justify-between mb-4">
          <button
            onClick={onJumpToNow}
            className="flex items-center gap-2 text-sm text-slate-600 hover:text-slate-900 hover:bg-slate-50 rounded-lg px-3 py-2 transition-colors"
          >
            <Calendar className="w-4 h-4" />
            <span className="font-medium">{formatTodaysDate()}</span>
          </button>
          <GoogleCalendarButton onSync={onGoogleSync} />
        </div>
        <h2 className="text-lg font-semibold text-gray-900">Tasks</h2>
      </div>

      <div className="flex-1 overflow-hidden flex flex-col">
        {categories.map(category => (
          <div 
            key={category.key} 
            className="flex flex-col min-h-0"
            style={{ flex: getFlexValue(category.key) }}
          >
            <div className="px-6 py-4 border-b border-gray-100">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className={`w-3 h-3 rounded-full ${category.color}`} />
                  <h3 className="font-medium text-gray-900">{category.title}</h3>
                  <span className="text-sm text-gray-500">
                    ({getTasksByCategory(category.key).filter(t => !t.completed).length})
                  </span>
                </div>
              </div>
              <input
                type="text"
                value={inputValues[category.key]}
                onChange={(e) => handleInputChange(category.key, e.target.value)}
                onKeyPress={(e) => handleKeyPress(category.key, e)}
                placeholder={`Add ${category.title.toLowerCase()} item...`}
                className="w-full px-3 py-2 text-sm border border-gray-300 rounded-lg focus:ring-2 focus:ring-slate-500 focus:border-transparent"
              />
            </div>

            <div className="flex-1 overflow-y-auto px-6 py-2">
              <div className="space-y-2">
                {getTasksByCategory(category.key).map(task => (
                  <TaskItem
                    key={task.id}
                    task={task}
                    onToggleComplete={onToggleTask}
                    onMove={onMoveTask}
                    onEdit={onEditTask}
                    onDragStart={onDragStart}
                  />
                ))}
                {getTasksByCategory(category.key).length === 0 && (
                  <div className="text-center py-4 text-gray-400">
                    <p className="text-sm">No tasks</p>
                  </div>
                )}
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default TaskSidebar;