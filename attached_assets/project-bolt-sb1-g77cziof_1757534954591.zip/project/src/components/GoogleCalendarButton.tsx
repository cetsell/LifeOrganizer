import React, { useState, useEffect } from 'react';
import { Calendar, LogIn, LogOut } from 'lucide-react';
import { initializeGoogleCalendar, signIn, signOut, isSignedIn } from '../services/googleCalendar';

interface GoogleCalendarButtonProps {
  onSync: () => void;
}

const GoogleCalendarButton: React.FC<GoogleCalendarButtonProps> = ({ onSync }) => {
  const [isInitialized, setIsInitialized] = useState(false);
  const [isSignedInState, setIsSignedInState] = useState(false);
  const [isLoading, setIsLoading] = useState(false);

  useEffect(() => {
    initializeGoogleApi();
  }, []);

  const initializeGoogleApi = async () => {
    setIsLoading(true);
    try {
      const initialized = await initializeGoogleCalendar();
      setIsInitialized(initialized);
      if (initialized) {
        setIsSignedInState(isSignedIn());
      }
    } catch (error) {
      console.error('Failed to initialize Google Calendar:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleSignIn = async () => {
    setIsLoading(true);
    try {
      const success = await signIn();
      if (success) {
        setIsSignedInState(true);
        onSync(); // Trigger sync after successful sign-in
      }
    } catch (error) {
      console.error('Sign-in failed:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleSignOut = () => {
    signOut();
    setIsSignedInState(false);
  };

  const handleSync = () => {
    if (isSignedInState) {
      onSync();
    }
  };

  if (!isInitialized) {
    return (
      <div className="flex items-center gap-2 text-sm text-gray-500">
        <Calendar className="w-4 h-4" />
        {isLoading ? 'Initializing...' : 'Setup Google Calendar in .env'}
      </div>
    );
  }

  if (!isSignedInState) {
    return (
      <button
        onClick={handleSignIn}
        disabled={isLoading}
        className="flex items-center gap-2 px-3 py-2 text-sm text-slate-600 hover:text-slate-900 hover:bg-slate-100 rounded-lg transition-colors disabled:opacity-50"
      >
        <LogIn className="w-4 h-4" />
        {isLoading ? 'Connecting...' : 'Connect Google Calendar'}
      </button>
    );
  }

  return (
    <div className="flex items-center gap-2">
      <button
        onClick={handleSync}
        className="flex items-center gap-2 px-3 py-2 text-sm text-green-600 hover:text-green-800 hover:bg-green-50 rounded-lg transition-colors"
      >
        <Calendar className="w-4 h-4" />
        Sync Calendar
      </button>
      <button
        onClick={handleSignOut}
        className="p-2 text-sm text-gray-500 hover:text-gray-700 rounded-lg transition-colors"
        title="Disconnect Google Calendar"
      >
        <LogOut className="w-4 h-4" />
      </button>
    </div>
  );
};

export default GoogleCalendarButton;