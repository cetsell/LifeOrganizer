import React, { useState } from 'react';
import { X, Calendar, Clock } from 'lucide-react';
import { CalendarEvent } from '../types';

interface EventModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (event: Omit<CalendarEvent, 'id'>) => void;
  onDelete?: () => void;
  initialDate: string;
  initialHour: number;
  existingEvent?: CalendarEvent;
}

const EventModal: React.FC<EventModalProps> = ({
  isOpen,
  onClose,
  onSave,
  onDelete,
  initialDate,
  initialHour,
  existingEvent
}) => {
  const [title, setTitle] = useState(existingEvent?.title || '');
  const [startTime, setStartTime] = useState(existingEvent?.startTime || `${initialHour.toString().padStart(2, '0')}:00`);
  const [endTime, setEndTime] = useState(existingEvent?.endTime || `${(initialHour + 1).toString().padStart(2, '0')}:00`);
  const [color, setColor] = useState(existingEvent?.color || '#F87171');
  const [notes, setNotes] = useState(existingEvent?.notes || '');

  const colors = [
    { value: '#F87171', name: 'Coral' },
    { value: '#34D399', name: 'Green' },
    { value: '#60A5FA', name: 'Blue' },
    { value: '#A78BFA', name: 'Purple' },
    { value: '#FBBF24', name: 'Yellow' },
    { value: '#F472B6', name: 'Pink' }
  ];

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim()) return;

    onSave({
      title: title.trim(),
      startTime,
      endTime,
      date: existingEvent?.date || initialDate,
      color,
      notes
    });

    // Reset form only if creating new event
    if (!existingEvent) {
      setTitle('');
      setStartTime(`${initialHour.toString().padStart(2, '0')}:00`);
      setEndTime(`${(initialHour + 1).toString().padStart(2, '0')}:00`);
      setColor('#F87171');
      setNotes('');
    }
    
    onClose();
  };

  const handleDelete = () => {
    if (onDelete) {
      onDelete();
      onClose();
    }
  };

  // Update form when existingEvent changes
  React.useEffect(() => {
    if (existingEvent) {
      setTitle(existingEvent.title);
      setStartTime(existingEvent.startTime);
      setEndTime(existingEvent.endTime);
      setColor(existingEvent.color);
      setNotes(existingEvent.notes || '');
    } else {
      setTitle('');
      setStartTime(`${initialHour.toString().padStart(2, '0')}:00`);
      setEndTime(`${(initialHour + 1).toString().padStart(2, '0')}:00`);
      setColor('#F87171');
      setNotes('');
    }
  }, [existingEvent, initialHour]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-lg shadow-xl w-full max-w-md">
        <div className="flex items-center justify-between p-6 border-b border-gray-200">
          <h2 className="text-lg font-semibold text-gray-900">
            {existingEvent ? 'Edit Event' : 'Add Event'}
          </h2>
          <button
            onClick={onClose}
            className="text-gray-400 hover:text-gray-600 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Event Title
            </label>
            <input
              type="text"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-slate-500 focus:border-transparent"
              placeholder="Enter event title"
              autoFocus
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Start Time
              </label>
              <input
                type="time"
                value={startTime}
                onChange={(e) => setStartTime(e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-slate-500 focus:border-transparent"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                End Time
              </label>
              <input
                type="time"
                value={endTime}
                onChange={(e) => setEndTime(e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-slate-500 focus:border-transparent"
              />
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Color
            </label>
            <div className="flex gap-2">
              {colors.map(colorOption => (
                <button
                  key={colorOption.value}
                  type="button"
                  onClick={() => setColor(colorOption.value)}
                  className={`w-8 h-8 rounded-full border-2 transition-all ${
                    color === colorOption.value ? 'border-gray-900 scale-110' : 'border-gray-300'
                  }`}
                  style={{ backgroundColor: colorOption.value }}
                />
              ))}
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Notes (Optional)
            </label>
            <textarea
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              rows={3}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-slate-500 focus:border-transparent resize-none"
              placeholder="Add event notes..."
            />
          </div>

          <div className="flex gap-3 pt-4">
            <button
              type="button"
              onClick={onClose}
              className="flex-1 px-4 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors"
            >
              Cancel
            </button>
            {existingEvent && onDelete && (
              <button
                type="button"
                onClick={handleDelete}
                className="px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 transition-colors"
              >
                Delete
              </button>
            )}
            <button
              type="submit"
              className="flex-1 px-4 py-2 bg-slate-600 text-white rounded-lg hover:bg-slate-700 transition-colors"
            >
              {existingEvent ? 'Update Event' : 'Save Event'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default EventModal;