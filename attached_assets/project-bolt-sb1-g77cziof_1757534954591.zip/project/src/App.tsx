import React, { useState, useEffect } from 'react';
import { Calendar } from 'lucide-react';
import { CalendarEvent, Task, TimeBlock as TimeBlockType, WeekData } from './types';
import { getWeekData, addWeeks, formatDate, isSameDay } from './utils/dateUtils';
import { useLocalStorage } from './hooks/useLocalStorage';
import { fetchEvents, createEvent, updateEvent, deleteEvent, isSignedIn } from './services/googleCalendar';
import WeekView from './components/WeekView';
import TaskSidebar from './components/TaskSidebar';
import EventModal from './components/EventModal';
import TaskModal from './components/TaskModal';

function App() {
  const [currentDate, setCurrentDate] = useState(new Date());
  const [expandedBlock, setExpandedBlock] = useState<string | null>(null);
  const [isEventModalOpen, setIsEventModalOpen] = useState(false);
  const [isTaskModalOpen, setIsTaskModalOpen] = useState(false);
  const [eventModalData, setEventModalData] = useState<{ hour: number; date: string } | null>(null);
  const [editingEvent, setEditingEvent] = useState<CalendarEvent | null>(null);
  const [editingTask, setEditingTask] = useState<Task | null>(null);
  const [isSyncing, setIsSyncing] = useState(false);

  // Responsive state
  const [isDesktop, setIsDesktop] = useState(window.innerWidth >= 1024);
  const [showWeekends, setShowWeekends] = useState(window.innerWidth >= 768);
  const [screenSize, setScreenSize] = useState<'mobile' | 'tablet' | 'desktop' | 'large' | 'ultrawide'>(() => {
    const width = window.innerWidth;
    if (width >= 1920) return 'ultrawide';
    if (width >= 1440) return 'large';
    if (width >= 1024) return 'desktop';
    if (width >= 768) return 'tablet';
    return 'mobile';
  });

  // Local storage hooks
  const [events, setEvents] = useLocalStorage<CalendarEvent[]>('calendar-events', []);
  const [tasks, setTasks] = useLocalStorage<Task[]>('tasks', [
    { id: '1', title: 'Draft Q3 Report', category: 'todo', completed: false, priority: 'high' },
    { id: '2', title: 'Review Design Mockups', category: 'todo', completed: false, priority: 'medium' },
    { id: '3', title: 'Prep for Friday Demo', category: 'todo', completed: false, priority: 'low' },
    { id: '4', title: 'Book Flight Tickets', category: 'upcoming', completed: false, dueDate: 'Dec 15' },
    { id: '5', title: 'Prep for Friday Demo', category: 'upcoming', completed: false, dueDate: 'Dec 20' },
    { id: '6', title: 'Organize Cloud Drive', category: 'upcoming', completed: false, dueDate: 'Dec 22' }
  ]);
  const [timeBlockNotes, setTimeBlockNotes] = useLocalStorage<Record<string, string>>('time-block-notes', {});

  // Get week data
  const currentWeek = getWeekData(currentDate);
  const previousWeek = getWeekData(addWeeks(currentDate, -1));
  const nextWeek = getWeekData(addWeeks(currentDate, 1));

  // Create time blocks structure
  const createTimeBlocks = (weekData: WeekData): Record<string, TimeBlockType> => {
    const blocks: Record<string, TimeBlockType> = {};
    
    for (let hour = 6; hour <= 23; hour++) {
      weekData.days.forEach(day => {
        const dateStr = formatDate(day);
        const blockKey = `${dateStr}-${hour}`;
        
        // Find events that overlap with this hour block
        const blockEvents = events.filter(event => {
          if (event.date !== dateStr) return false;
          
          const startHour = parseInt(event.startTime.split(':')[0]);
          const endHour = parseInt(event.endTime.split(':')[0]);
          const endMinutes = parseInt(event.endTime.split(':')[1]);
          
          // Event overlaps if it starts before or during this hour, and ends after this hour starts
          return startHour <= hour && (endHour > hour || (endHour === hour + 1 && endMinutes === 0));
        });
        
        blocks[blockKey] = {
          hour,
          date: dateStr,
          events: blockEvents,
          notes: timeBlockNotes[blockKey] || ''
        };
      });
    }
    
    return blocks;
  };

  // Create time blocks for individual day view (when expanded)
  const createDayTimeBlocks = (date: string): Record<string, TimeBlockType> => {
    const blocks: Record<string, TimeBlockType> = {};
    
    for (let hour = 6; hour <= 23; hour++) {
      const blockKey = `${date}-${hour}`;
      
      // Find events that overlap with this hour block
      const blockEvents = events.filter(event => {
        if (event.date !== date) return false;
        
        const startHour = parseInt(event.startTime.split(':')[0]);
        const endHour = parseInt(event.endTime.split(':')[0]);
        const endMinutes = parseInt(event.endTime.split(':')[1]);
        
        // Event overlaps if it starts before or during this hour, and ends after this hour starts
        return startHour <= hour && (endHour > hour || (endHour === hour + 1 && endMinutes === 0));
      });
      
      blocks[blockKey] = {
        hour,
        date: date,
        events: blockEvents,
        notes: timeBlockNotes[blockKey] || ''
      };
    }
    
    return blocks;
  };

  // Get expanded day if any block is expanded
  const getExpandedDay = (): string | null => {
    if (!expandedBlock) return null;
    return expandedBlock.split('-').slice(0, -1).join('-'); // Remove hour part
  };

  const expandedDay = getExpandedDay();
  const expandedDayBlocks = expandedDay ? createDayTimeBlocks(expandedDay) : {};

  // Filter current week days - if one day is expanded, show others condensed
  const getCurrentWeekDisplay = () => {
    if (!expandedDay) {
      // No day expanded, show all days normally
      return currentWeek.days.map(day => ({
        day,
        isExpanded: false,
        timeBlocks: createTimeBlocks({ ...currentWeek, days: [day] })
      }));
    }
    
    // One day is expanded
    return currentWeek.days.map(day => {
      const dateStr = formatDate(day);
      const isThisExpanded = dateStr === expandedDay;
      
      return {
        day,
        isExpanded: isThisExpanded,
        timeBlocks: isThisExpanded ? expandedDayBlocks : createTimeBlocks({ ...currentWeek, days: [day] })
      };
    });
  };

  const currentWeekDisplay = getCurrentWeekDisplay();

  const timeBlocks = createTimeBlocks(currentWeek);

  // Handle time block expansion
  const handleTimeBlockClick = (hour: number, date: string) => {
    const blockKey = `${date}-${hour}`;
    setExpandedBlock(expandedBlock === blockKey ? null : blockKey);
  };

  // Handle notes change
  const handleNotesChange = (hour: number, date: string, notes: string) => {
    const blockKey = `${date}-${hour}`;
    setTimeBlockNotes(prev => ({
      ...prev,
      [blockKey]: notes
    }));
  };

  // Handle event creation
  const handleAddEvent = (hour: number, date: string) => {
    setEventModalData({ hour, date });
    setIsEventModalOpen(true);
  };

  const handleSaveEvent = (eventData: Omit<CalendarEvent, 'id'>) => {
    if (editingEvent) {
      // Update existing event
      const updatedEvent = { ...eventData, id: editingEvent.id };
      setEvents(prev => 
        prev.map(event => 
          event.id === editingEvent.id ? updatedEvent : event
        )
      );
      
      // Sync with Google Calendar if signed in
      if (isSignedIn()) {
        updateEvent(updatedEvent).catch(console.error);
      }
      
      setEditingEvent(null);
    } else {
      // Create new event
      const newEvent: CalendarEvent = {
        ...eventData,
        id: Date.now().toString()
      };
      setEvents(prev => [...prev, newEvent]);
      
      // Sync with Google Calendar if signed in
      if (isSignedIn()) {
        createEvent(newEvent).catch(console.error);
      }
    }
  };

  const handleDeleteEvent = () => {
    if (editingEvent) {
      setEvents(prev => prev.filter(event => event.id !== editingEvent.id));
      
      // Delete from Google Calendar if signed in
      if (isSignedIn()) {
        deleteEvent(editingEvent.id).catch(console.error);
      }
      
      setEditingEvent(null);
    }
  };

  const handleEditEvent = (event: CalendarEvent) => {
    setEditingEvent(event);
    setIsEventModalOpen(true);
  };

  // Handle task operations
  const handleAddTask = (category: Task['category'], title: string) => {
    const newTask: Task = {
      id: Date.now().toString(),
      title,
      category,
      completed: false
    };
    setTasks(prev => [...prev, newTask]);
  };

  const handleEditTask = (task: Task) => {
    setEditingTask(task);
    setIsTaskModalOpen(true);
  };

  const handleSaveTask = (taskData: Omit<Task, 'id'>) => {
    if (editingTask) {
      // Update existing task
      setTasks(prev =>
        prev.map(task =>
          task.id === editingTask.id
            ? { ...taskData, id: editingTask.id }
            : task
        )
      );
      setEditingTask(null);
    } else {
      // Create new task
      const newTask: Task = {
        ...taskData,
        id: Date.now().toString()
      };
      setTasks(prev => [...prev, newTask]);
    }
  };

  const handleDeleteTask = () => {
    if (editingTask) {
      setTasks(prev => prev.filter(task => task.id !== editingTask.id));
      setEditingTask(null);
    }
  };

  const handleToggleTask = (id: string) => {
    setTasks(prev => 
      prev.map(task => 
        task.id === id ? { ...task, completed: !task.completed } : task
      )
    );
  };

  const handleMoveTask = (id: string, category: Task['category']) => {
    setTasks(prev =>
      prev.map(task =>
        task.id === id ? { ...task, category } : task
      )
    );
  };

  // Handle jump to now
  const handleJumpToNow = () => {
    const now = new Date();
    setCurrentDate(now);
    
    // Expand current hour if it's within range
    const currentHour = now.getHours();
    if (currentHour >= 6 && currentHour <= 23) {
      const todayStr = formatDate(now);
      setExpandedBlock(`${todayStr}-${currentHour}`);
    } else {
      setExpandedBlock(null);
    }
  };

  // Handle drag and drop
  const handleTaskDragStart = (e: React.DragEvent, task: Task) => {
    e.dataTransfer.setData('text/plain', task.id);
  };

  const handleTaskDrop = (hour: number, date: string, taskId: string) => {
    const task = tasks.find(t => t.id === taskId);
    if (!task) return;

    // Create event from task
    const newEvent: CalendarEvent = {
      id: Date.now().toString(),
      title: task.title,
      startTime: `${hour.toString().padStart(2, '0')}:00`,
      endTime: `${(hour + 1).toString().padStart(2, '0')}:00`,
      date,
      color: task.priority === 'high' ? '#F87171' : task.priority === 'medium' ? '#FBBF24' : '#60A5FA'
    };

    setEvents(prev => [...prev, newEvent]);
    
    // Mark task as completed or remove it
    setTasks(prev => prev.filter(t => t.id !== taskId));
  };

  // Navigation handlers
  const handlePreviousWeek = () => {
    setCurrentDate(prev => addWeeks(prev, -1));
    setExpandedBlock(null);
  };

  const handleNextWeek = () => {
    setCurrentDate(prev => addWeeks(prev, 1));
    setExpandedBlock(null);
  };

  const handleToday = () => {
    setCurrentDate(new Date());
    setExpandedBlock(null);
  };

  // Handle Google Calendar sync
  const handleGoogleSync = async () => {
    if (!isSignedIn()) return;
    
    setIsSyncing(true);
    try {
      // Get events for the current month
      const startOfMonth = new Date(currentDate.getFullYear(), currentDate.getMonth(), 1);
      const endOfMonth = new Date(currentDate.getFullYear(), currentDate.getMonth() + 1, 0);
      
      const googleEvents = await fetchEvents(startOfMonth, endOfMonth);
      
      // Merge with existing local events (avoiding duplicates)
      setEvents(prev => {
        const localEventIds = new Set(prev.map(e => e.id));
        const newGoogleEvents = googleEvents.filter(e => !localEventIds.has(e.id));
        return [...prev, ...newGoogleEvents];
      });
      
    } catch (error) {
      console.error('Sync failed:', error);
    } finally {
      setIsSyncing(false);
    }
  };

  const handleWeekNavigation = (weeksOffset: number) => {
    setCurrentDate(prev => addWeeks(prev, weeksOffset));
    setExpandedBlock(null);
  };

  // Auto-expand current hour on page load
  useEffect(() => {
    const now = new Date();
    if (isSameDay(now, new Date())) {
      const currentHour = now.getHours();
      if (currentHour >= 6 && currentHour <= 23) {
        const todayStr = formatDate(now);
        setExpandedBlock(`${todayStr}-${currentHour}`);
      }
    }
  }, []);

  // Handle responsive changes
  useEffect(() => {
    const handleResize = () => {
      const width = window.innerWidth;
      setIsDesktop(window.innerWidth >= 1024);
      setShowWeekends(window.innerWidth >= 768);
      
      if (width >= 1920) {
        setScreenSize('ultrawide');
      } else if (width >= 1440) {
        setScreenSize('large');
      } else if (width >= 1024) {
        setScreenSize('desktop');
      } else if (width >= 768) {
        setScreenSize('tablet');
      } else {
        setScreenSize('mobile');
      }
    };

    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  return (
    <>
      <div className="h-screen flex flex-col bg-gray-100">
        <div className="flex-1 flex overflow-hidden relative">
        <div className="flex-1 flex flex-col p-4 space-y-3 overflow-hidden">
          {/* Previous Week */}
          <WeekView
            weekData={previousWeek}
            timeBlocks={createTimeBlocks(previousWeek)}
            expandedBlock={null}
            onTimeBlockClick={() => {}}
            onNotesChange={() => {}}
            onAddEvent={() => {}}
            onEditEvent={() => {}}
            onTaskDrop={() => {}}
            isCondensed
            title="Previous Week"
            showWeekends={showWeekends}
            onWeekClick={() => handleWeekNavigation(-1)}
          />

          {/* Current Week */}
          <div className="flex-1 min-h-0">
            <WeekView
              weekData={currentWeek} 
              timeBlocks={{}} // Not used when dayDisplay is provided
              expandedBlock={expandedBlock}
              onTimeBlockClick={handleTimeBlockClick}
              onNotesChange={handleNotesChange}
              onAddEvent={handleAddEvent}
              onEditEvent={handleEditEvent}
              onTaskDrop={handleTaskDrop}
              showWeekends={showWeekends}
              dayDisplay={currentWeekDisplay}
            />
          </div>

          {/* Next Week */}
          <WeekView
            weekData={nextWeek}
            timeBlocks={createTimeBlocks(nextWeek)}
            expandedBlock={null}
            onTimeBlockClick={() => {}}
            onNotesChange={() => {}}
            onAddEvent={() => {}}
            onEditEvent={() => {}}
            onTaskDrop={() => {}}
            isCondensed
            title="Next Week"
            showWeekends={showWeekends}
            screenSize={screenSize}
            onWeekClick={() => handleWeekNavigation(1)}
          />
        </div>

        {/* Task Sidebar - Hidden on mobile/tablet */}
        {isDesktop && (
          <TaskSidebar
            tasks={tasks}
            onGoogleSync={handleGoogleSync}
            onAddTask={handleAddTask}
            onToggleTask={handleToggleTask}
            onMoveTask={handleMoveTask}
            onEditTask={handleEditTask}
            onDragStart={handleTaskDragStart}
            onJumpToNow={handleJumpToNow}
          />
        )}

        {/* Mobile Task Toggle Button */}
        {!isDesktop && (
          <button
            className="fixed bottom-4 right-4 bg-slate-600 text-white p-3 rounded-full shadow-lg hover:bg-slate-700 transition-colors z-50"
            onClick={() => setIsTaskModalOpen(true)}
          >
            <Calendar className="w-5 h-5" />
          </button>
        )}
      </div>
      </div>

      <EventModal
        isOpen={isEventModalOpen}
        onClose={() => {
          setIsEventModalOpen(false);
          setEditingEvent(null);
        }}
        onSave={handleSaveEvent}
        onDelete={editingEvent ? handleDeleteEvent : undefined}
        initialDate={eventModalData?.date || formatDate(new Date())}
        initialHour={eventModalData?.hour || new Date().getHours()}
        existingEvent={editingEvent || undefined}
      />

      <TaskModal
        isOpen={isTaskModalOpen}
        onClose={() => {
          setIsTaskModalOpen(false);
          setEditingTask(null);
        }}
        onSave={handleSaveTask}
        onDelete={editingTask ? handleDeleteTask : undefined}
        existingTask={editingTask || undefined}
      />
    </>
  );
}

export default App;