import { CalendarEvent } from '../types';

const CLIENT_ID = import.meta.env.VITE_GOOGLE_CLIENT_ID;
const API_KEY = import.meta.env.VITE_GOOGLE_API_KEY;
const DISCOVERY_DOC = 'https://www.googleapis.com/discovery/v1/apis/calendar/v3/rest';
const SCOPES = 'https://www.googleapis.com/auth/calendar';

let gapi: any;
let tokenClient: any;
let isInitialized = false;

export const initializeGoogleCalendar = async (): Promise<boolean> => {
  try {
    // Check if required environment variables are present
    if (!CLIENT_ID || !API_KEY || CLIENT_ID === 'your_google_client_id_here' || API_KEY === 'your_google_api_key_here') {
      console.warn('Google Calendar API credentials not configured. Please set up .env file with valid VITE_GOOGLE_CLIENT_ID and VITE_GOOGLE_API_KEY');
      return false;
    }

    // Load Google API script
    if (!window.gapi) {
      await loadScript('https://apis.google.com/js/api.js');
    }
    
    if (!window.google) {
      await loadScript('https://accounts.google.com/gsi/client');
    }

    gapi = window.gapi;

    // Initialize gapi
    await new Promise((resolve) => {
      gapi.load('client', resolve);
    });

    await gapi.client.init({
      apiKey: API_KEY,
      discoveryDocs: [DISCOVERY_DOC],
    });

    // Initialize Google Identity Services
    tokenClient = window.google.accounts.oauth2.initTokenClient({
      client_id: CLIENT_ID,
      scope: SCOPES,
      callback: '', // Will be set later
    });

    isInitialized = true;
    return true;
  } catch (error) {
    console.error('Error initializing Google Calendar:', error);
    return false;
  }
};

const loadScript = (src: string): Promise<void> => {
  return new Promise((resolve, reject) => {
    const script = document.createElement('script');
    script.src = src;
    script.onload = () => resolve();
    script.onerror = () => reject(new Error(`Failed to load script: ${src}`));
    document.head.appendChild(script);
  });
};

export const signIn = (): Promise<boolean> => {
  return new Promise((resolve) => {
    tokenClient.callback = async (response: any) => {
      if (response.error) {
        resolve(false);
        return;
      }
      resolve(true);
    };

    if (gapi.client.getToken() === null) {
      tokenClient.requestAccessToken({ prompt: 'consent' });
    } else {
      tokenClient.requestAccessToken({ prompt: '' });
    }
  });
};

export const signOut = () => {
  const token = gapi.client.getToken();
  if (token !== null) {
    window.google.accounts.oauth2.revoke(token.access_token);
    gapi.client.setToken('');
  }
};

export const isSignedIn = (): boolean => {
  return gapi?.client?.getToken() !== null;
};

const convertGoogleEventToCalendarEvent = (googleEvent: any): CalendarEvent => {
  const start = googleEvent.start?.dateTime || googleEvent.start?.date;
  const end = googleEvent.end?.dateTime || googleEvent.end?.date;
  
  let startTime = '09:00';
  let endTime = '10:00';
  let date = new Date().toISOString().split('T')[0];

  if (start) {
    const startDate = new Date(start);
    date = startDate.toISOString().split('T')[0];
    startTime = startDate.toTimeString().slice(0, 5);
  }

  if (end) {
    const endDate = new Date(end);
    endTime = endDate.toTimeString().slice(0, 5);
  }

  return {
    id: googleEvent.id || Date.now().toString(),
    title: googleEvent.summary || 'Untitled Event',
    startTime,
    endTime,
    date,
    color: '#60A5FA', // Default blue color
    notes: googleEvent.description || ''
  };
};

const convertCalendarEventToGoogle = (event: CalendarEvent) => {
  const startDateTime = `${event.date}T${event.startTime}:00`;
  const endDateTime = `${event.date}T${event.endTime}:00`;

  return {
    summary: event.title,
    description: event.notes || '',
    start: {
      dateTime: startDateTime,
      timeZone: Intl.DateTimeFormat().resolvedOptions().timeZone,
    },
    end: {
      dateTime: endDateTime,
      timeZone: Intl.DateTimeFormat().resolvedOptions().timeZone,
    },
  };
};

export const fetchEvents = async (startDate: Date, endDate: Date): Promise<CalendarEvent[]> => {
  if (!isInitialized || !isSignedIn()) {
    throw new Error('Google Calendar not initialized or user not signed in');
  }

  try {
    const response = await gapi.client.calendar.events.list({
      calendarId: 'primary',
      timeMin: startDate.toISOString(),
      timeMax: endDate.toISOString(),
      showDeleted: false,
      singleEvents: true,
      orderBy: 'startTime',
    });

    const items = response.result.items || [];
    return items.map(convertGoogleEventToCalendarEvent);
  } catch (error) {
    console.error('Error fetching events:', error);
    throw error;
  }
};

export const createEvent = async (event: CalendarEvent): Promise<CalendarEvent> => {
  if (!isInitialized || !isSignedIn()) {
    throw new Error('Google Calendar not initialized or user not signed in');
  }

  try {
    const googleEvent = convertCalendarEventToGoogle(event);
    const response = await gapi.client.calendar.events.insert({
      calendarId: 'primary',
      resource: googleEvent,
    });

    return convertGoogleEventToCalendarEvent(response.result);
  } catch (error) {
    console.error('Error creating event:', error);
    throw error;
  }
};

export const updateEvent = async (event: CalendarEvent): Promise<CalendarEvent> => {
  if (!isInitialized || !isSignedIn()) {
    throw new Error('Google Calendar not initialized or user not signed in');
  }

  try {
    const googleEvent = convertCalendarEventToGoogle(event);
    const response = await gapi.client.calendar.events.update({
      calendarId: 'primary',
      eventId: event.id,
      resource: googleEvent,
    });

    return convertGoogleEventToCalendarEvent(response.result);
  } catch (error) {
    console.error('Error updating event:', error);
    throw error;
  }
};

export const deleteEvent = async (eventId: string): Promise<void> => {
  if (!isInitialized || !isSignedIn()) {
    throw new Error('Google Calendar not initialized or user not signed in');
  }

  try {
    await gapi.client.calendar.events.delete({
      calendarId: 'primary',
      eventId: eventId,
    });
  } catch (error) {
    console.error('Error deleting event:', error);
    throw error;
  }
};